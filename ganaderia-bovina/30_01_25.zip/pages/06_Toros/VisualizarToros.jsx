import "../../styles/ListaAnimales.css";
import {NavLink} from "react-router-dom";

export const VisualizarToros = () => {


    return (
        <>
            <div className="contenedor">
                <div className="cuadradoVisualizarLista">VISUALIZAR LISTA DE ANIMALES</div>
                {/*<NavLink to="/agregar-animal" className="btn btn-info boton-derecha">AÑADIR ANIMAL</NavLink>*/}

                {/* Botón para AGREGAR un nuevo animal (vaca/ternero)*/}
                <NavLink
                    to="/formulario-animal"
                    state={{modo: "agregar"}} // Se pasa el estado "Agregar"
                    className="btn btn-info boton-derecha"
                >
                    AÑADIR ANIMAL
                </NavLink>
            </div>
            <hr/>
            {/*Añade una línea/raya */}

            <div className="listaAnimales">Lista de toros:</div>
            <table className="table">
                <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">NOMBRE</th>
                    <th scope="col">ACCIONES</th>
                </tr>
                </thead>
                <tbody>
                {/* Botones que aparecen al lado de cada uno de los animales: VER - MODIFICAR - ELIMINAR*/}

                </tbody>
            </table>

            {/* BOTÓN DE VOLVER AL MENÚ PRINCIPAL*/}
            <div className="boton-volver">
                <NavLink to="/" className="btn btn-info">
                    VOLVER AL MENÚ
                </NavLink>
            </div>
        </>
    );
};