export const AgregarCorral = () => {
    return (
        <div>
            Agregar corral
        </div>
    )
}