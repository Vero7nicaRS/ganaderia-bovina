
//Inventario de vacunas y tratamientos
export const InventarioVT = () => {
    return (
        <div>
            Inventario vacunas y/o tratamientos
        </div>
    )
}