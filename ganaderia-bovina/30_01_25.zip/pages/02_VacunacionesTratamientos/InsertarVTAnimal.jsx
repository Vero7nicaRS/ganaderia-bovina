
export const InsertarVTAnimal = () => {
    return (
        <div>
            Insertar vacuna y/o tratamiento a un animal
        </div>
    )
}