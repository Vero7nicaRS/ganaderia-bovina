export const ListaCorrales = () => {
    return (
        <div>
            Lista de corrales
        </div>
    )
}