import './styles/App.css'
import './styles/cuadradosHome.css'
import {Navigate, Route, Routes} from "react-router-dom";
import Home from "./pages/Home.jsx";
import GestionVacas from "./pages/GestionVacas.jsx"
import {NavBar} from "./components/NavBar.jsx"
import {Footer} from "./components/Footer.jsx"
import {ListaAnimales} from "./pages/ListaAnimales.jsx";
import {AgregarAnimal} from "./pages/AgregarAnimal.jsx";
import {InventarioVT} from "./pages/InventarioVT.jsx";
import {AgregarTipoVT} from "./pages/AgregarTipoVT.jsx";
import {InsertarVTAnimal} from "./pages/InsertarVTAnimal.jsx";
import {ListaCorrales} from "./pages/ListaCorrales.jsx";
import {AgregarCorral} from "./pages/AgregarCorral.jsx";
import {ListaInseminaciones} from "./pages/ListaInseminaciones.jsx";
import {InseminacionAnimal} from "./pages/InseminacionAnimal.jsx";
import {SimulacionCrias} from "./pages/SimulacionCrias.jsx";
import {VisualizarToros} from "./pages/VisualizarToros.jsx";
import {AgregarToro} from "./pages/AgregarToro.jsx";
export const App = () => {
     return (
         <>
             <div className="cuadradoBienvenida"> ¡Bienvenido, ____ !</div>
             <hr/>
             <div className="cuadradoQueHacer"> ¿Qué desea hacer hoy?</div>

             <NavBar></NavBar>
             <div>
                 <div className="container">
                     <Routes>
                         <Route path="/" element={<Home/>}/>
                         <Route path="/gestion-vacas" element={<GestionVacas/>}/>
                         <Route path="/visualizar-animales" element={<ListaAnimales/>}/>
                         <Route path="/agregar-animal" element={<AgregarAnimal/>}/>
                         <Route path="/inventario-vt" element={<InventarioVT/>}/>
                         <Route path="/agregar-tipo-vt" element={<AgregarTipoVT/>}/>
                         <Route path="/insertar-vt-animal" element={<InsertarVTAnimal/>}/>
                         <Route path="/lista-corrales" element={<ListaCorrales/>}/>
                         <Route path="/agregar-corral" element={<AgregarCorral/>}/>
                         <Route path="/lista-inseminaciones" element={<ListaInseminaciones/>}/>
                         <Route path="/inseminacion-animal" element={<InseminacionAnimal/>}/>
                         <Route path="/simulacion-crias" element={<SimulacionCrias/>}/>
                         <Route path="/visualizar-toros" element={<VisualizarToros/>}/>
                         <Route path="/agregar-toro" element={<AgregarToro/>}/>

                         <Route path="/*" element={<Navigate to='/'/>}></Route>

                     </Routes>
                 </div>
                 <Footer ></Footer>

             </div>
         </>
         //     <>
         //         <NavBar></NavBar>
         //         <div>
         //             <Header /> {/* Tu componente de navegación */}
    //             <div className="container">
    //                 <Routes>
    //                     <Route path="/" element={<Home/>}/>
    //                     <Route path="/gestion-vacas" element={<GestionVacas/>}/>
    //                     <Route path="/contacto" element={<Contacto/>}/>
    //                 </Routes>
    //             </div>
    //
    //         </>

)
}
