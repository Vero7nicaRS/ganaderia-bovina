import {NavLink} from "react-router-dom"


export const NavBar = () => {

    return (
        // <nav className="navbar navbar-expand-lg bg-body-tertiary">
        //     <div className="container-fluid">
        //         <NavLink to='/gestion-vacas' className="navbar-brand" href="#">Gestion vacas </NavLink>
        //         <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        //             <span className="navbar-toggler-icon"></span>
        //         </button>
        //         <div className="collapse navbar-collapse" id="navbarSupportedContent">
        //             <ul className="navbar-nav me-auto mb-2 mb-lg-0">
        //                 <li className="nav-item">
        //                     <NavLink to='/contacto' className="nav-link active">CONTACTO</NavLink>
        //                 </li>
        //             </ul>
        //
        //         </div>
        //     </div>
        // </nav>
        <nav className="navbar navbar-expand-lg bg-body-tertiary">
            <div className="container-fluid">
                <NavLink to='/gestion-vacas' className="navbar-brand" href="#">Gestion vacas </NavLink>
                <button className="navbar-toggler" type="button" data-bs-toggle="collapse"
                        data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>
                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                        <li className="nav-item dropdown">
                            <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                               aria-expanded="false">
                                Animales
                            </a>
                            <ul className="dropdown-menu">

                                <li><NavLink to='/visualizar-animales' className="dropdown-item">Visualizar animales</NavLink></li>
                                <li>
                                    <hr className="dropdown-divider"/>
                                </li>
                                <li><NavLink to='/agregar-animal' className="dropdown-item">Agregar animal</NavLink></li>
                            </ul>
                        </li>

                        <li className="nav-item dropdown">
                            <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                               aria-expanded="false">
                                Vacunas/Tratamientos
                            </a>
                            <ul className="dropdown-menu">
                                <li><NavLink to='/inventario-vt' className="dropdown-item">Inventario</NavLink></li>
                                <li>
                                    <hr className="dropdown-divider"/>
                                </li>
                                <li><NavLink to='/agregar-tipo-vt' className="dropdown-item">Agregar nuevo tipo</NavLink></li>
                                <li>
                                    <hr className="dropdown-divider"/>
                                </li>
                                <li><NavLink to='/insertar-vt-animal' className="dropdown-item">Insertar tipo al animal</NavLink></li>

                            </ul>

                        </li>
                        <li className="nav-item dropdown">
                            <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                               aria-expanded="false">
                                Movimientos de corral
                            </a>
                            <ul className="dropdown-menu">
                                <li><NavLink to='/lista-corrales' className="dropdown-item">Lista de corrales</NavLink></li>
                                <li>
                                    <hr className="dropdown-divider"/>
                                </li>
                                <li><NavLink to='/agregar-corral' className="dropdown-item">Agregar corral</NavLink></li>
                            </ul>
                        </li>
                        <li className="nav-item dropdown">
                            <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                               aria-expanded="false">
                                Inseminaciones
                            </a>
                            <ul className="dropdown-menu">
                                <li><NavLink to='/lista-inseminaciones' className="dropdown-item">Lista de inseminaciones</NavLink></li>
                                <li>
                                    <hr className="dropdown-divider"/>
                                </li>
                                <li><NavLink to='/inseminacion-animal' className="dropdown-item">Inseminación animal</NavLink></li>
                            </ul>
                        </li>
                        <li className="nav-item">
                            <NavLink to='/simulacion-crias' className="dropdown-item">Simulación crías</NavLink>
                        </li>
                        <li className="nav-item dropdown">
                            <a className="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown"
                               aria-expanded="false">
                                Toros
                            </a>
                            <ul className="dropdown-menu">
                                <li><NavLink to='/visualizar-toros' className="dropdown-item">Visualizar toros</NavLink></li>
                                <li>
                                    <hr className="dropdown-divider"/>
                                </li>
                                <li><NavLink to='/agregar-toro' className="dropdown-item">Agregar toro</NavLink></li>
                            </ul>

                        </li>
                    </ul>
                    {/*<form className="d-flex" role="search">*/}
                    {/*    <input className="form-control me-2" type="search" placeholder="Search" aria-label="Search"/>*/}
                    {/*    <button className="btn btn-outline-success" type="submit">Search</button>*/}
                    {/*</form>*/}
                </div>
            </div>
        </nav>

    )
}
