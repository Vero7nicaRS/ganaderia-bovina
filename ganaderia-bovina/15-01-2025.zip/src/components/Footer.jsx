import "../styles/Footer.css"
export const Footer = () => {
    return (
        <div>
            {/*Se va a realizar el pie de página */}
            <footer className="cuadradoDiseñoRealizado">Diseño realizado por: Verónica Rodríguez Sánchez</footer>
        </div>
    )
}
