export const ListaInseminaciones = () => {
    return (
        <div>
            Lista de inseminaciones
        </div>
    )
}