
export const VisualizarToros = () => {
    return (
        <div>
            visualizar toros
        </div>
    )
}