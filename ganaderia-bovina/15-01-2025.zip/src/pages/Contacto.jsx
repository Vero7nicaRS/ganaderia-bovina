const Contacto = () => {
    return (
        <div>
            <h2>Página de contacto</h2>
        </div>
    );
};

export default Contacto;