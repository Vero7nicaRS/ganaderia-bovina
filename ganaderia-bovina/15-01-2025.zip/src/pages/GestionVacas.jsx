const GestionVacas = () => {
    return (
        <div>
            <h2>Gestion de vacas</h2>
        </div>
    );
};

export default GestionVacas;