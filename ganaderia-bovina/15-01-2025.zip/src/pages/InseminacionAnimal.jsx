export const InseminacionAnimal = () => {
    return (
        <div>
            InseminacionAnimal
        </div>
    )
}