export const AgregarTipoVT= () => {
    return (
        <div>
            Agregar vacuna y/o tratamiento
        </div>
    )
}