import "../styles/stylesAll.css"
const Home = () => {
    return (
        <div>
            <h2>Bienvenido a Gestión ganadera</h2>
            <p>Esta es la página principal de la aplicación.</p>

        </div>
    );
};

export default Home;