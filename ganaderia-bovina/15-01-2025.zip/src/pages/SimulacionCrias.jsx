export const SimulacionCrias = () => {
    return (
        <div>
            Simulación de crías
        </div>
    )
}