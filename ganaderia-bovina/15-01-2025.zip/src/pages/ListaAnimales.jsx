export const ListaAnimales = () => {
    return (
        <div>
            <h1>Lista animales</h1>
        </div>
    );
};