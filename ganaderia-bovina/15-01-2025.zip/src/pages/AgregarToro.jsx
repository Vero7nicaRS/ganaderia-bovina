export const AgregarToro = () => {
    return (
        <div>
            Agregar toro
        </div>
    )
}