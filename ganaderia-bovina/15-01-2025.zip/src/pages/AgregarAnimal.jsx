export const AgregarAnimal = () => {
    return (
        <div>
            Agregar animal
        </div>
    )
}
